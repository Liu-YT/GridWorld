public class helloworld {

	public String sayHello() {
		return ("Hello World!");
	}

	public static void main(String args[]) {
		helloworld temp = new helloworld();
		System.out.println(temp.sayHello());
	}
}
